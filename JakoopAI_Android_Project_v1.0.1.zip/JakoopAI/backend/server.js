import express from "express";
import cors from "cors";
import { OAuth2Client } from "google-auth-library";

const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));

const PORT = process.env.PORT || 8080;
const API_KEY = process.env.AI_API_KEY;
const MODEL = process.env.AI_MODEL || "gpt-4.1-mini";
const API_BASE = process.env.AI_API_BASE || "https://api.openai.com/v1";
const OWNER_EMAIL = (process.env.OWNER_EMAIL || "yaqoophanna333@gmail.com").toLowerCase();
const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID || "";
const googleClient = new OAuth2Client(GOOGLE_CLIENT_ID);

// Verify a Google ID token and allow only the configured owner account.
app.post("/api/auth/google", async (req, res) => {
  try {
    if (!GOOGLE_CLIENT_ID) return res.status(503).json({ error: "Google OAuth is not configured yet." });
    const credential = String(req.body?.idToken || "");
    if (!credential) return res.status(400).json({ error: "idToken is required" });
    const ticket = await googleClient.verifyIdToken({
      idToken: credential,
      audience: GOOGLE_CLIENT_ID
    });
    const payload = ticket.getPayload();
    const email = String(payload?.email || "").toLowerCase();
    if (!payload?.email_verified || email !== OWNER_EMAIL) {
      return res.status(403).json({ error: "This Google account is not authorized." });
    }
    // This endpoint confirms identity only. A production session/token and rate limits
    // must be added before public deployment.
    return res.json({ ok: true, email, name: payload?.name || "" });
  } catch {
    return res.status(401).json({ error: "Invalid Google identity token." });
  }
});

app.get("/health", (_req, res) => res.json({ ok: true, service: "Jakoop AI" }));

app.post("/api/chat", async (req, res) => {
  try {
    if (!API_KEY) return res.status(503).json({ error: "AI_API_KEY is not configured on server." });
    const message = String(req.body?.message || "").trim();
    if (!message) return res.status(400).json({ error: "message is required" });

    const upstream = await fetch(`${API_BASE}/chat/completions`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: MODEL,
        messages: [
          { role: "system", content: "You are Jakoop AI, a careful multilingual assistant. Be accurate, distinguish facts from uncertainty, and answer in the user's language." },
          { role: "user", content: message }
        ]
      })
    });
    const data = await upstream.json();
    if (!upstream.ok) return res.status(upstream.status).json({ error: data?.error?.message || "AI provider error" });
    res.json({ reply: data?.choices?.[0]?.message?.content || "" });
  } catch {
    res.status(500).json({ error: "Internal server error" });
  }
});

app.listen(PORT, () => console.log(`Jakoop AI backend listening on ${PORT}`));
