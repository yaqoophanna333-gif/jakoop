package com.jakoop.ai

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object AiClient {
    // Set this to your deployed HTTPS backend URL. Never put provider API keys in the APK.
    private const val BACKEND_URL = "https://YOUR_BACKEND_DOMAIN.example/api/chat"
    private val client = OkHttpClient()

    suspend fun ask(message: String): String = withContext(Dispatchers.IO) {
        if (BACKEND_URL.contains("YOUR_BACKEND_DOMAIN")) {
            return@withContext "واجهة Jakoop AI جاهزة. لتفعيل الذكاء الاصطناعي الحقيقي، يجب ربط التطبيق بخادم آمن وإضافة مفتاح مزوّد الذكاء الاصطناعي على الخادم، وليس داخل الهاتف."
        }
        try {
            val payload = JSONObject().put("message", message)
            val body = payload.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder().url(BACKEND_URL).post(body).build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext "تعذّر الاتصال بالخدمة (${response.code})."
                val json = JSONObject(response.body?.string().orEmpty())
                json.optString("reply", "وصل رد فارغ من الخادم.")
            }
        } catch (e: Exception) {
            "لم أتمكن من الاتصال بالخادم. تحقق من اتصال الإنترنت وإعدادات الخدمة."
        }
    }
}
