package com.jakoop.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private val Ink = Color(0xFF111827)
private val Accent = Color(0xFF7C5CFC)
private val SurfaceDark = Color(0xFF1B2230)

data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JakoopApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JakoopApp() {
    var prompt by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var drawerOpen by remember { mutableStateOf(false) }
    val messages = remember { mutableStateListOf<ChatMessage>() }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Accent, background = Ink, surface = SurfaceDark,
        onBackground = Color.White, onSurface = Color.White
    )) {
        ModalNavigationDrawer(
            drawerState = rememberDrawerState(if (drawerOpen) DrawerValue.Open else DrawerValue.Closed),
            drawerContent = {
                ModalDrawerSheet(drawerContainerColor = SurfaceDark) {
                    Text("Jakoop AI", modifier = Modifier.padding(22.dp),
                        fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    NavigationDrawerItem(label = { Text("محادثة جديدة") },
                        selected = true, onClick = { messages.clear(); drawerOpen = false },
                        icon = { Icon(Icons.Default.Add, null) })
                    Text("سجل المحادثات سيُضاف في النسخة التالية",
                        modifier = Modifier.padding(18.dp), color = Color.LightGray)
                }
            }
        ) {
            Scaffold(
                containerColor = Ink,
                topBar = {
                    TopAppBar(
                        title = { Column {
                            Text("Jakoop AI", fontWeight = FontWeight.Bold)
                            Text("مساعدك الذكي", fontSize = 11.sp, color = Color.LightGray)
                        } },
                        navigationIcon = {
                            IconButton(onClick = { drawerOpen = true }) {
                                Icon(Icons.Default.Menu, "القائمة")
                            }
                        },
                        actions = {
                            Text("BETA", color = Accent, modifier = Modifier.padding(end = 16.dp),
                                fontWeight = FontWeight.Bold)
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = Ink, titleContentColor = Color.White)
                    )
                },
                bottomBar = {
                    Row(
                        modifier = Modifier.fillMaxWidth().background(SurfaceDark)
                            .imePadding().padding(horizontal = 10.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { /* file picker will be wired in next build */ }) {
                            Icon(Icons.Default.AttachFile, "إرفاق", tint = Color.LightGray)
                        }
                        OutlinedTextField(
                            value = prompt, onValueChange = { prompt = it },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text("اكتب رسالتك هنا...", color = Color.Gray) },
                            shape = RoundedCornerShape(22.dp), maxLines = 5,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                                focusedBorderColor = Accent, unfocusedBorderColor = Color.DarkGray
                            )
                        )
                        IconButton(
                            enabled = prompt.isNotBlank() && !busy,
                            onClick = {
                                val text = prompt.trim()
                                messages.add(ChatMessage(text, true))
                                prompt = ""
                                busy = true
                                scope.launch {
                                    val answer = AiClient.ask(text)
                                    messages.add(ChatMessage(answer, false))
                                    busy = false
                                }
                            }
                        ) {
                            Icon(Icons.Default.Send, "إرسال", tint = Accent)
                        }
                    }
                }
            ) { padding ->
                if (messages.isEmpty()) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier.size(76.dp).background(Accent, RoundedCornerShape(24.dp)),
                            contentAlignment = Alignment.Center
                        ) { Text("J", fontSize = 42.sp, fontWeight = FontWeight.Black, color = Color.White) }
                        Spacer(Modifier.height(22.dp))
                        Text("أهلاً بك في Jakoop AI", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text("اسأل، اكتب، ترجم، حلّل، وابدأ مشروعك.",
                            color = Color.LightGray)
                        Spacer(Modifier.height(26.dp))
                        listOf("اشرح لي موضوعاً بالتفصيل", "ساعدني في كتابة نص احترافي",
                            "حلّل صورة أو ملفاً").forEach { suggestion ->
                            OutlinedButton(onClick = { prompt = suggestion },
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                Text(suggestion, color = Color.White)
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp),
                        contentPadding = PaddingValues(vertical = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(messages) { msg ->
                            Row(Modifier.fillMaxWidth(),
                                horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start) {
                                Surface(
                                    color = if (msg.fromUser) Color(0xFF34304D) else SurfaceDark,
                                    shape = RoundedCornerShape(18.dp),
                                    modifier = Modifier.widthIn(max = 320.dp)
                                ) {
                                    Text(msg.text, modifier = Modifier.padding(14.dp),
                                        color = Color.White, lineHeight = 23.sp)
                                }
                            }
                        }
                        if (busy) item { Text("Jakoop AI يفكر...", color = Color.LightGray) }
                    }
                }
            }
        }
    }
}
